# Scripts

## sync-code-snippets.js

Verifies if the Turtle and JSON-LD code snippets are in sync and generates JSON-LD for missing or out-of-sync code snippets.

Call the script with `--help` for usage information.
