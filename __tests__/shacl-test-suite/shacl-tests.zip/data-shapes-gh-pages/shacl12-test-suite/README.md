# SHACL 1.2 test-suite

This repository contains the SHACL test-suite for SHACL 1.2.

The format follows the previously published
http://w3c.github.io/data-shapes/data-shapes-test-suite/

The content from the data-shapes-test-suite folder remains unaffected, for SHACL 1.0.