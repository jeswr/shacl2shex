# SHACL test-suite

This repository contains the SHACL test-suite.

The test-suite follows the W3c convention used for Turtle tests. 
It consists of a manifest file manifest.ttl which enumerates all the tests. 

The folder "contrib" contains some tests that have been contributed but haven't been edited yet.

More information: http://w3c.github.io/data-shapes/data-shapes-test-suite/

 
